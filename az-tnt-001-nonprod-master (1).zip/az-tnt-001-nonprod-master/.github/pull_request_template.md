[template]
SCP = STDCHG0001371
CI  = Kubernetes Cluster tnt-001-nonprod-ea8f086d.hcp.northeurope.azmk8s.io:443
IOC = 5dfb3decdb42c300f2e65845dc9619cf
ENV = Development
PDSM = NONPROD

[changelog]


[comments]
Lines starting with # will be stripped. empty lines will also be stripped when PR body is updated with PDSM ticket log.
Links to backlog/tickets items should go here.
