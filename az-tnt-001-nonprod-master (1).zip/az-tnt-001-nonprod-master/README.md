# TNT Non-Production Kubernetes Cluster
![tnt-001-nonprod](https://healthchecks.io/badge/58bfaf30-102b-4d2e-8c7f-fc1c6b/sKqJ_7fE/tnt-001-nonprod.svg)

As we have been receiving multiple requests from various teams for VMs with Docker installed we have setup a generic AKS (Azure Kubernetes Service) Cluster. This is not only cost effective but it also provides a standard managed platform for deploying containers.

# Application onboarding
For applications to exist within the cluster a FedEx Corp AD group must be created with the format: 'azure_tnt_<myapp1>'.
See <https://github.az.fxei.fedex.com/terraform/aks-app-onboarding>

# Ingress Controller
Our chosen ingress-controller is Traefik.
A wildcard cert has been setup to support all ingress rules.

| Ingress Class | URL | Description |
| --- | --- | --- |
| traefik-internal | <https://*.tnt-001.tntnpk.az.fxei.fedex.com> | Allows traffic from internal/on-prem only |
| traefik-external | <https://*.nonprod-apps.tnt.com> | Allows internal/on-prem and public traffic |

# Extras
#### This module shipped now with commonly available middlwares
Middleware available for use:
* SSL Redirect: https-redirect@file
* HSTS Headers: hsts@file
* No Sniff: nosniff@file
* Frame Deny: frame-deny@file
* Frame Sameorigin: frame-sameorigin@file (only one of the frame middleware possible)
* XSS Filter: xss@file

#### Example how to use middleware(s) with annotations
For example we want add SSL Redirect and HSTS Headers, then annotations for ingress should have record below:
```yaml
ingress:
  myingress:
    enabled: true
    annotations:
      traefik.ingress.kubernetes.io/router.middlewares: "https-redirect@file,hsts@file"
```

#### Example how to use middleware with app-generic chart and ingress controller `type: crd`
```yaml
ingress:
  myingress:
    enabled: true
    type: crd
    traefik:
      middlewares:
        - name: https-redirect@file
        - name: hsts@file
        - name: nosniff@file
        - name: frame-sameorigin@file
        - name: xss@file
```

# Network
Network is controlled by the az-network plan.
This AKS cluster has access to TNT network only.

# Sandbox Namespace Housekeeping
Any namespace matching *-sandbox is automatically cleaned weekly.
This is done via a Jenkins job currently running @ <https://jenkins.tools.fxi-svc.az.fxei.fedex.com/job/k8s/job/sandbox-cleanup>

# Monitoring
Prometheus, Grafana and Alert Manager are installed as part of the cluster and are available

| Tool | URL |
| --- | --- |
| Kubernetes Dashboard | <https://dashboard.tnt-001.tntnpk.az.fxei.fedex.com> |
| Traefik Dashboard | <https://traefik-int.tnt-001.tntnpk.az.fxei.fedex.com> |
| Prometheus | <https://prometheus.tnt-001.tntnpk.az.fxei.fedex.com> |
| Grafana | <https://grafana.tnt-001.tntnpk.az.fxei.fedex.com> |

# Alerting
Currently all alerting goes to the following teams channels:
* [Critical Alerts](https://teams.microsoft.com/l/channel/19%3a7fcc7c709fcd40bb86463a606c28c901%40thread.skype/TNT%2520AKS%2520-%2520NonProd%2520-%2520Critical?groupId=21e5a7d4-e29e-4350-9eaf-31b8b29276ae&tenantId=b945c813-dce6-41f8-8457-5a12c2fe15bf)
* [Warning Alerts](https://teams.microsoft.com/l/channel/19%3aa8e52f3d54494557a7e7e5178c11d2b6%40thread.skype/TNT%2520AKS%2520-%2520NonProd%2520-%2520Warning?groupId=21e5a7d4-e29e-4350-9eaf-31b8b29276ae&tenantId=b945c813-dce6-41f8-8457-5a12c2fe15bf)

The monitoring watchdog alert is setup to send to [healthchecks.io](https://healthchecks.io/) every hour. If the alert is not received an alert is sent to the [Critical Alerts](https://teams.microsoft.com/l/channel/19%3a7fcc7c709fcd40bb86463a606c28c901%40thread.skype/TNT%2520AKS%2520-%2520NonProd%2520-%2520Critical?groupId=21e5a7d4-e29e-4350-9eaf-31b8b29276ae&tenantId=b945c813-dce6-41f8-8457-5a12c2fe15bf) teams channel.

# Architecture
![Architecture](assets/architecture.png)

# Flow
![Flow](assets/flow.png)

# Kubernetes Flow
![Flow](assets/k8s-flow.png)

# Architecture - PDF
There is a PDF version available [here](assets/tnt-001-nonprod-v0.0.2.pdf).

